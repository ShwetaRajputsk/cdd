package com.example.crop_disease_detection_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
